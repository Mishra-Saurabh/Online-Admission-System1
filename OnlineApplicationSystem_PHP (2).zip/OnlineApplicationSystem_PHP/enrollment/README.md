# Online Admission System


•	The system enables the student to fill application forms online and submit it. They also submit their necessary documents like passport size photograph, certificates and marksheets along with the identity proof. 

•	The Manager can view the application forms and can approve or disapprove them. He can submit the CUEE marks of the students.

•	If it is approved, an email will be sent to the Student’s email ID and the admit card can be downloaded from the student’s account. The students can further view their results. 

•	This system helps in reducing the manual efforts and consumes less time.

OBJECTIVE


•	To reduce the processing time and acquire more accurate information. 

•	To ensure reliability.

•	Generate Student’s Academic Detail Report.

•	Generate Student’s Personal Detail Report along with the necessary documents.

•	Database maintained by this system usually contains the student’s personal and academic related information. It focuses on storing and processing data by using web pages.

•	To make the system more user friendly. 
